# BUILD REPORT (v2.4) — 빌드별 벤치마크

빌드당 일반 구간 200판 + PARADOX CORE 200판, 조건 간 동일 seed 세트. 레벨업 약 5회 기준(일반 구간은 실제 레벨업 진행, 보스는 5회 선택 후 시작).

우선순위: ATTACK = SHARP EDGE > RAPID CUT > LONG REACH (남는 선택은 공격 계열) / ECHO = ECHO POWER > DEEP RECORD > RESONANCE / DASH = PHASE TRAIL > PHASE DRIVE > IMPACT > PHASE MARK / HYBRID = RESONANCE > PHASE MARK > FEEDBACK LOOP > ECHO POWER > PHASE TRAIL / RANDOM = 기준선(무작위 선택, 판정 제외).
봇: 일반 구간 sweeper(사망 가능), 보스 BOT B. 모든 빌드가 동일한 봇 조건(쿨이 돌면 적/보스 쪽으로 공격 대시 사용)으로 플레이하므로 차이는 업그레이드 선택에서만 나온다.

## 일반 구간 (60초)

| 빌드 | 60초 생존 | 평균 생존시간 | 처치 | 총 DPS | 직접 공격 DPS | PLAYER 피해 | ECHO 피해 | DASH·TRAIL 피해 | 시너지 피해 | RESONANCE/분 | MARK/분 | 최종 LV |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ATTACK | 0% | 57.3s | 33.8 | 1.19 | 0.70 | 75% | 25% | 28% | 0% | 0.0 | 0.0 | 5.8 |
| ECHO | 0% | 56.3s | 32.9 | 1.18 | 0.64 | 72% | 28% | 32% | 0% | 0.0 | 0.0 | 5.8 |
| DASH | 0% | 57.3s | 34.0 | 1.20 | 0.60 | 72% | 28% | 40% | 0% | 0.0 | 0.0 | 5.8 |
| HYBRID | 0% | 56.1s | 32.7 | 1.18 | 0.64 | 73% | 27% | 33% | 0% | 0.1 | 0.1 | 5.8 |
| RANDOM | 0% | 56.8s | 33.5 | 1.19 | 0.65 | 74% | 26% | 33% | 0% | 0.0 | 0.0 | 5.8 |

(PLAYER+ECHO 피해 비율 합 = 100%. DASH·TRAIL은 두 주체의 대시/트레일 피해를 합친 값이고 PLAYER/ECHO 비율과 겹친다. 시너지 = RESONANCE+PHASE MARK 추가 피해.)

## PARADOX CORE

| 빌드 | 클리어율 | 클리어 시간 | 받은 피해 | SYNC BREAK | PLAYER 피해 | ECHO 피해 | 시너지 피해 | 보스 DPS | RESONANCE | MARK |
|---|---|---|---|---|---|---|---|---|---|---|
| ATTACK | 100% | 24.2s | 0.81 | 3.5 | 40% | 60% | 4% | 7.55 | 3.8 | 1.9 |
| ECHO | 100% | 24.7s | 1.03 | 3.6 | 35% | 65% | 11% | 7.34 | 15.0 | 2.7 |
| DASH | 100% | 27.2s | 0.75 | 3.9 | 39% | 61% | 7% | 6.68 | 3.1 | 5.2 |
| HYBRID | 100% | 25.1s | 1.21 | 3.6 | 40% | 60% | 20% | 7.24 | 18.1 | 7.3 |
| RANDOM | 100% | 25.1s | 0.78 | 3.6 | 38% | 62% | 9% | 7.27 | 8.8 | 4.6 |

(보스 피해 비율: PLAYER + ECHO + 시너지 = 100%. PLAYER/ECHO는 시너지 추가 피해를 제외한 기본/대시/트레일 피해.)

## BUILD DOMINANCE 판정

기준: 다른 3개 빌드 평균 대비 총 DPS +25% / 처치량 +25% / 생존율 +20%p / 보스 클리어 시간 20% 단축 중 3개 이상 동시 만족.

| 빌드 | DPS | 처치 | 생존율(%p) | 보스 시간 단축 | 충족 수 | 판정 |
|---|---|---|---|---|---|---|
| ATTACK | +1% | +2% | +0% | +6% | 0 | - |
| ECHO | -0% | -2% | +0% | +3% | 0 | - |
| DASH | +1% | +3% | +0% | -10% | 0 | - |
| HYBRID | -1% | -3% | +0% | +1% | 0 | - |

영역별 1위: 일반 전투(DPS) → DASH / 생존(60초 생존율) → ATTACK / 보스(클리어 시간) → ATTACK

세 영역 모두 1위인 빌드: 없음

## 빌드 성격 체크 (성공 기준)

- ✅ ATTACK: 직접 공격(PLAYER 기본 공격) DPS 최고 — ATTACK 0.70 / ECHO 0.64 / DASH 0.60 / HYBRID 0.64
- ✅ ECHO: ECHO 피해 비율 최고 (일반+보스 평균) — ATTACK 42% / ECHO 47% / DASH 44% / HYBRID 44%
- ✅ DASH: DASH·TRAIL 피해 비율 최고 — ATTACK 28% / ECHO 32% / DASH 40% / HYBRID 33%
- ✅ DASH: 생존성(평균 생존시간 또는 보스 받은 피해)이 다른 빌드 평균보다 우수 — 생존시간 57.3s (타 평균 56.6s), 보스 받은 피해 0.75 (타 평균 1.02)
- ✅ HYBRID: RESONANCE/PHASE MARK 발동 빈도 최고 (일반, 분당) — ATTACK 0.0 / ECHO 0.1 / DASH 0.1 / HYBRID 0.2
- ✅ HYBRID: 시너지 피해 비율(ECHO 활용 보상) 최고 — ATTACK 2% / ECHO 5% / DASH 3% / HYBRID 10%
